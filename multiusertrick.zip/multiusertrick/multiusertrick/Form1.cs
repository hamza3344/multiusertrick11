﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
namespace multiusertrick
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Environment.UserName;
                var options = new ChromeOptions();
                options.AddArgument(@"--user-data-dir=c:\Users\" + username + @"\AppData\Local\Google\Chrome\User Data\");
                options.AddArgument(@"--profile-directory=Default");
                IWebDriver driver = new ChromeDriver(Application.StartupPath + "/drivers/", options);
            }
            catch(Exception e1)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Environment.UserName;
                var options = new ChromeOptions();
                options.AddArgument(@"--user-data-dir=c:\Users\" + username + @"\AppData\Local\Google\Chrome\User Data\");
                options.AddArgument(@"--profile-directory=Profile 1");
                IWebDriver driver = new ChromeDriver(Application.StartupPath + "/drivers/", options);
            }
            catch (Exception e1)
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string username = Environment.UserName;
                var options = new ChromeOptions();
                options.AddArgument(@"--user-data-dir=c:\Users\" + username + @"\AppData\Local\Google\Chrome\User Data\");
                options.AddArgument(@"--profile-directory=Profile 2");
                IWebDriver driver = new ChromeDriver(Application.StartupPath + "/drivers/", options);
            }
            catch (Exception e1)
            {

            }
        }
    }
}
